MODULE Module1
    PERS tooldata tcp_grinding_pin_gripper:=[TRUE,[[85.423,-0.00173,165.548],[0.86600793,0.000094054,0.500030249,0.000076173]],[0.25,[-17.37,0,58.3],[1,0,0,0],0,0,0]];
    PERS wobjdata wobj_customer_boxes:=[FALSE,TRUE,"",[[413.748,246.408,234],[0.707106781,-0,0,-0.707106781]],[[0,0,0],[1,0,0,0]]];
    PERS wobjdata wobj_pin_machine:=[FALSE,TRUE,"",[[400.91,-144,231],[0.69411529,0.134922065,-0.134922065,-0.69411529]],[[0,0,0],[1,0,0,0]]];
    CONST robtarget home:=[[465.011102618,-0.00173,437.247511933],[0.000055366,0.707026876,-0.707186675,0.000005964],[0,-1,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,0]];
    CONST robtarget machine_sef_pos:=[[-10,65.649333215,189.182887834],[0.190808614,0.981627258,0,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,0]];
    CONST robtarget Target_420:=[[254.5,186,27.5],[0.000000001,0.923879533,-0.382683432,-0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,0]];
    CONST robtarget Target_380:=[[254.5,58,27.5],[0.000000001,0.923879533,-0.382683432,-0],[0,-1,1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,0]];
    CONST robtarget Target_40:=[[36.5,30.001,25.001],[0,1,0,0],[-1,1,-2,0],[9E+09,9E+09,9E+09,9E+09,9E+09,0]];
    CONST robtarget home_box1_3:=[[465.011102618,209.911938356,437.247511933],[0.000055366,0.707026876,-0.707186675,0.000005964],[0,-1,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,0]];
    CONST robtarget home_box1:=[[465.011102618,-0.00173,437.247511933],[0.000055366,0.707026876,-0.707186675,0.000005964],[0,-1,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,0]];
    CONST robtarget Target_300:=[[36.5,186,27.5],[0,0.923879533,0.382683432,0],[0,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,0]];
    CONST robtarget Target_300_2:=[[36.5,186,77.5],[0,0.923879533,0.382683432,0],[0,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,0]];
    
    
    
    PROC main()
        Path_10;
        Path_20;
    ENDPROC
    
    
    PROC Path_10()
        MoveL home,v150,z20,tcp_gripper_x_to_side\WObj:=wobj0;
    ENDPROC
    PROC Path_20()
        MoveL home_box1,v150,z20,tcp_gripper_x_to_side\WObj:=wobj0;
        MoveL home_box1_3,v150,z20,tcp_gripper_x_to_side\WObj:=wobj0;
        MoveL Target_300_2,v100,z20,tcp_gripper_x_to_side\WObj:=wobj_customer_boxes;
        MoveL Target_300,v150,z20,tcp_gripper_x_to_side\WObj:=wobj_customer_boxes;
        MoveL home_box1_3,v150,z20,tcp_gripper_x_to_side\WObj:=wobj0;
        MoveL home_box1,v150,z20,tcp_gripper_x_to_side\WObj:=wobj0;
        MoveL machine_sef_pos,v150,z20,tcp_gripper_x_to_side\WObj:=wobj_pin_machine;
        MoveL Target_40,v150,z20,tcp_gripper_x_to_side\WObj:=wobj_pin_machine;
    ENDPROC
ENDMODULE